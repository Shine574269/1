%% Q3_abcdefg.m - Complete FM Signal Analysis
clear; clc; close all;

%% Parameters (Common for all parts)
student_id_last_digit = 6; % Replace with your student ID's last digit
fc = 5e5;                  % Carrier frequency: 500 kHz
fm = 1e4;                  % Modulation frequency: 10 kHz
Fs = 1e7;                  % Sampling frequency: 10 MHz
duration = 3e-4;           % Signal duration: 0.3 ms
beta_table = [2, 2.2, 2.4, 2.6, 2.8, 3, 3.2, 3.4, 3.6, 3.8];
beta = beta_table(student_id_last_digit + 1);

%% Q3-a: Theoretical Spectrum Analysis
n = -5:5;
J = besselj(n, beta);

figure(1);
stem(n, J, 'filled', 'LineWidth', 1.5);
xlabel('n (harmonic number)');
ylabel('J_n(β) Amplitude');
title(sprintf('Q3-a: Bessel Coefficients for β = %.1f', beta));
grid on;


n_max = 10; % Maximum order of sidebands to consider
f_theoretical = fc + (-n_max:n_max)*fm; % Theoretical frequencies
J = besselj(-n_max:n_max, beta); % Bessel function values

disp('Theoretical spectrum components:');
disp('Frequency (Hz)    Amplitude');
disp([f_theoretical' abs(J)']);


%% Q3-b: Generate FM Signal
t = 0:1/Fs:duration;
x_FM = cos(2*pi*fc*t + (beta/(2*pi*fm))*sin(2*pi*fm*t));

figure(2);
subplot(2,1,1);
plot(t(1:1000)*1e6, x_FM(1:1000));
xlabel('Time (μs)'); ylabel('Amplitude');
title('Q3-b: FM Signal (First 100 μs)'); grid on;

subplot(2,1,2);
plot(t*1e3, x_FM);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Q3-b: FM Signal (Full Duration)'); grid on;
fprintf('FM signal parameters:\n');
fprintf('Carrier frequency (fc): %.1f kHz\n', fc/1e3);
fprintf('Modulation frequency (fm): %.1f kHz\n', fm/1e3);
fprintf('Modulation index (¦Â): %.1f\n', beta);
fprintf('Sampling frequency: %.1f MHz\n', Fs/1e6);
fprintf('Duration: %.1f ¦Ìs\n\n', duration*1e6);

%% Q3-c: Frequency Spectrum
N = length(x_FM);
f = (-Fs/2:Fs/N:Fs/2-Fs/N);
X_FM = fftshift(fft(x_FM)/N);

figure(3);
subplot(2,1,1);
plot(f/1e3, 20*log10(abs(X_FM)));
xlabel('Frequency (kHz)'); ylabel('Magnitude (dB)');
title('Q3-c: FM Spectrum (Full View)'); grid on;
xlim([-Fs/2/1e3, Fs/2/1e3]);

subplot(2,1,2);
plot(f/1e3, 20*log10(abs(X_FM)));
xlabel('Frequency (kHz)'); ylabel('Magnitude (dB)');
title('Q3-c: FM Spectrum (Zoomed)'); grid on;
xlim([fc/1e3-150, fc/1e3+150]); ylim([-100, 0]);

hold on;
plot([fc/1e3, fc/1e3], ylim, 'r--');
for k = -5:5
    plot([(fc+k*fm)/1e3, (fc+k*fm)/1e3], ylim, 'g--');
end
hold off;
legend('Spectrum', 'Carrier', 'Sidebands');

%% Q3-d: Verification
n_sidebands = -5:5;
J_dB = 20*log10(abs(besselj(n_sidebands, beta)));

measured_dB = zeros(size(n_sidebands));
for k = 1:length(n_sidebands)
    [~,idx] = min(abs(f - (fc + n_sidebands(k)*fm)));
    measured_dB(k) = 20*log10(abs(X_FM(idx)));
end

figure(4);
stem(n_sidebands, J_dB, 'filled', 'LineWidth', 2);
hold on;
stem(n_sidebands, measured_dB, 'LineWidth', 1.5);
hold off;
xlabel('Sideband Index (n)'); ylabel('Magnitude (dB)');
title('Q3-d: Theoretical vs Measured Sidebands');
legend('Theoretical', 'Measured'); grid on;

corr_coeff = corrcoef(J_dB, measured_dB);
fprintf('Q3-d: Correlation coefficient: %.4f\n', corr_coeff(1,2));

%% Q3-e: Differentiation and Envelope Analysis
dx_FM = gradient(x_FM, t);
env = abs(hilbert(dx_FM));

figure(5);
subplot(2,1,1);
plot(t*1e3, dx_FM);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Q3-e: Differentiated FM Signal'); grid on;

subplot(2,1,2);
plot(t*1e3, env);
xlabel('Time (ms)'); ylabel('Envelope');
title('Q3-e: Envelope of Differentiated Signal'); grid on;

% Verify fm frequency in envelope
[pxx, f_env] = pwelch(env-mean(env), [], [], [], Fs);
[~, idx] = max(pxx);
fprintf('Q3-e: Dominant envelope frequency: %.2f kHz (Expected: %.1f kHz)\n',...
        f_env(idx)/1e3, fm/1e3);

%% Q3-f: Hard Limiter
threshold = 0.1;
x_limited = min(max(x_FM, -threshold), threshold);

figure(6);
plot(t*1e3, x_limited);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Q3-f: Hard Limited FM Signal'); grid on;
ylim([-threshold*1.1, threshold*1.1]);

%% Q3-g: Hard Limiter Spectrum
X_limited = fftshift(fft(x_limited)/N);

figure(7);
subplot(2,1,1);
plot(f/1e3, 20*log10(abs(X_limited)));
xlabel('Frequency (kHz)'); ylabel('Magnitude (dB)');
title('Q3-g: Limited Signal Spectrum (Full)'); grid on;
xlim([-Fs/2/1e3, Fs/2/1e3]);

subplot(2,1,2);
plot(f/1e3, 20*log10(abs(X_limited)));
xlabel('Frequency (kHz)'); ylabel('Magnitude (dB)');
title('Q3-g: Limited Signal Spectrum (Zoomed)'); grid on;
xlim([fc/1e3-200, fc/1e3+200]); ylim([-100, 0]);

%% Q3-h: Bandpass Filter Reconstruction
bpFilt = designfilt('bandpassfir', ...
                   'CutoffFrequency1', fc-2*(beta+1)*fm, ...
                   'CutoffFrequency2', fc+2*(beta+1)*fm, ...
                   'SampleRate', Fs, ...
                   'FilterOrder', 200);
x_filtered = filtfilt(bpFilt, x_limited);

X_filtered = fftshift(fft(x_filtered)/N);

figure(8);
subplot(2,1,1);
plot(t*1e3, x_filtered);
xlabel('Time (ms)'); ylabel('Amplitude');
title('Q3-h: Reconstructed FM Signal'); grid on;

subplot(2,1,2);
plot(f/1e3, 20*log10(abs(X_filtered)));
xlabel('Frequency (kHz)'); ylabel('Magnitude (dB)');
title('Q3-h: Reconstructed Spectrum'); grid on;
xlim([fc/1e3-150, fc/1e3+150]);

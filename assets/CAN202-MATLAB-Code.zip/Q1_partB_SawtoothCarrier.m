%% Q1_partB_SawtoothCarrier.m
% Part B: Sawtooth-based Carrier and DSB-SC AM

clear all;
close all;
clc;

%% Load Handel and resample (from Q1)
load handel; % y, Fs

% Last non-zero digit of student ID
last_non_zero_digit = 6;
fc = last_non_zero_digit * 1e5; % Carrier frequency = 500000 Hz

% Compute new sampling frequency
Fs_new = ceil((Fs/2 + fc)/Fs * 2) * Fs;
disp(['Carrier Frequency fc = ' num2str(fc) ' Hz']);
disp(['Resampled Sampling Frequency Fs_{new} = ' num2str(Fs_new) ' Hz']);

% Resample Handel signal
y_resampled = resample(y, Fs_new, Fs);
t_mod = (0:length(y_resampled)-1)' / Fs_new;

%% (m) Generate sawtooth wave and extract sinusoidal carrier using bandpass filter
t_saw = (0:1/Fs_new:0.01)';  % Short time vector for display
saw_wave = sawtooth(2*pi*fc*t_saw);  % Sawtooth at carrier frequency

% Apply bandpass filter to isolate sinusoidal component near fc
filtered_carrier = bandpass(saw_wave, [fc-1000 fc+1000], Fs_new);

% Plot filtered carrier waveform
figure;
plot(t_saw, filtered_carrier);
title('Q1m: Filtered Sinusoidal Carrier from Sawtooth Wave');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

disp('Q1m: Filtered a sinusoidal wave at carrier frequency from a sawtooth signal.');

%% (n) Generate DSB-SC AM using sawtooth-derived carrier
full_saw = sawtooth(2*pi*fc*t_mod);  % Generate full-length sawtooth wave
carrier_full = bandpass(full_saw, [fc-1000 fc+1000], Fs_new);  % Filter it
dsb_sc_saw = y_resampled .* carrier_full;  % Modulation

disp('Q1n: Generated DSB-SC AM signal using the filtered sawtooth carrier.');

%% (o) Multiply with cosine and apply lowpass filter (Demodulation)
cos_wave = cos(2*pi*fc*t_mod);  % Coherent demodulation
demodulated = dsb_sc_saw .* cos_wave;

% Apply lowpass filter to extract baseband signal
baseband_filtered = lowpass(demodulated, Fs/2, Fs_new);  % Fs/2 = Nyquist rate of original signal

% Plot FFT of baseband signal
N = length(baseband_filtered);
f = (-N/2:N/2-1)*(Fs_new/N);
Y_baseband = fftshift(fft(baseband_filtered)/N);

figure;
plot(f, abs(Y_baseband));
title('Q1o: Frequency Spectrum of Demodulated Baseband Signal');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
grid on;
xlim([-5000 5000]);  % As required in Q1d

disp('Q1o: Demodulated signal and plotted the baseband frequency spectrum.');


%% (p) Downsample and play recovered signal with original scale
% Ensure we're using the signal from Q1-o (baseband_filtered)
if ~exist('baseband_filtered', 'var')
    error('Signal from Q1-o not found. Please run previous sections first.');
end


y_recovered = resample(baseband_filtered, Fs, Fs_new);


y_recovered = y_recovered / max(abs(y_recovered)) * 0.9; % Scale to 90% of maximum


player = audioplayer(y_recovered, Fs);

% Play the audio
disp('Playing downsampled signal from Q1-o...');
play(player);


fprintf('Playing: [');
playback_time = length(y_recovered)/Fs;
tic;
while toc < playback_time
    fprintf('=');
    pause(playback_time/10);
end
fprintf('] Done.\n');


fprintf('\nAudio Quality Report:\n');
fprintf('Duration: %.2f seconds\n', length(y_recovered)/Fs);
fprintf('Sampling rate: %d Hz\n', Fs);
fprintf('Signal range: [%.4f, %.4f]\n', min(y_recovered), max(y_recovered));

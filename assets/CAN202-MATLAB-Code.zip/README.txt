CAN202 Analogue and Digital Communications I - MATLAB coursework (Mengxuan Shen, 2025)

Q1_partA_DSBSC.m           DSB-SC AM modulation and coherent demodulation of MATLAB's built-in "handel" sample
Q1_partB_SawtoothCarrier.m DSB-SC AM with a carrier band-pass filtered out of a sawtooth wave
Q2_Superheterodyne.m       Superheterodyne receiver: picks one of ten DSB-SC channels and matches it to the original music
Q3_FM_Analysis.m           FM signal: Bessel-function spectrum, envelope detection, hard limiter and band-pass reconstruction

Requires MATLAB with the Signal Processing Toolbox.
Q2 needs the course-provided files soundtrack.mat and 001.mat-010.mat in the parent folder; they are not included here.
Full write-up: https://shine574269.github.io/assets/CAN202_Communications_Report.pdf

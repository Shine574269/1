%% Q2 - Superheterodyne Receiver
clear; clc; close all;

%% Parameters
load('../soundtrack.mat');     
Fs_rx = Fs_new;              
student_id_last_digit = 6;   
Fc_table = 1e5:2e4:2.8e5;     
Fc = Fc_table(student_id_last_digit + 1); 
Fi = 5e4;                    
Fs_baseband = 10000;          

%% (a) Plot the frequency spectrum of the input signal
L = length(soundtrack);
f = linspace(-Fs_rx/2, Fs_rx/2, L);
spectrum = abs(fftshift(fft(soundtrack)));
figure; plot(f, spectrum);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Q2-a: Spectrum of soundtrack');
grid on;

%% (b) Identify the 10 DSB-SC AM signals
L = length(soundtrack);
f = linspace(-Fs_rx/2, Fs_rx/2, L); % Frequency axis
spectrum = abs(fftshift(fft(soundtrack))); % FFT magnitude

figure;
subplot(2,1,1);
plot(f/1e3, spectrum); % Convert frequency to kHz
xlabel('Frequency (kHz)');
ylabel('Magnitude');
title('Q2-a: Spectrum of Composite DSB-SC Signal');
grid on;

%Identify 10 modulated signals
% Define parameters
BW_baseband = Fs_baseband;    % Baseband bandwidth: 10 kHz
BW_DSBSC = 2 * BW_baseband;   % DSB-SC bandwidth: 20 kHz

% Mark all carrier frequencies on spectrum
hold on;
for k = 1:10
    Fc_k = Fc_table(k)/1e3;  % Convert to kHz
    plot([Fc_k, Fc_k], [0, max(spectrum)], 'r--', 'LineWidth', 0.5);
    text(Fc_k, max(spectrum)*0.9, sprintf('Fc=%d', Fc_k), ...
        'HorizontalAlignment', 'center', 'FontSize', 8);
end
hold off;

% Create results table
signal_info = cell(10, 3);
for k = 1:10
    signal_info{k,1} = k;                     % Signal number
    signal_info{k,2} = Fc_table(k)/1e3;      % Carrier frequency (kHz)
    signal_info{k,3} = BW_DSBSC/1e3;         % Bandwidth (kHz)
end

% Display results in command window
disp('=== Parameters of 10 Modulated Signals ===');
disp('Signal No. | Carrier (kHz) | BW (kHz)');
disp('----------------------------------');
for k = 1:10
    fprintf('%4d      | %8.0f      | %6.0f\n', ...
            signal_info{k,1}, signal_info{k,2}, signal_info{k,3});
end

% Visualize results in figure
subplot(2,1,2);
axis off;
text(0.1, 0.9, 'Parameters of 10 DSB-SC Signals:', 'FontSize', 12, 'FontWeight', 'bold');
text(0.1, 0.7, 'Signal No. | Carrier (kHz) | BW (kHz)', 'FontSize', 10);
for k = 1:10
    text(0.1, 0.6-0.05*k, ...
        sprintf('%2d           %3.0f             %2.0f', ...
        k, Fc_table(k)/1e3, BW_DSBSC/1e3), 'FontSize', 10);
end

%% (c) Minimum required channel bandwidth
%% Load and analyze the signal
Fs_rx = Fs_new;           
%% Calculate spectrum parameters
L = length(soundtrack);
f = linspace(-Fs_rx/2, Fs_rx/2, L);
spectrum = abs(fftshift(fft(soundtrack)));

%% Find signal components
% Normalize and threshold the spectrum
normalized_spectrum = spectrum/max(spectrum);
threshold = 0.1;  % 10% threshold to identify significant signals
signal_mask = normalized_spectrum > threshold;

%% Calculate occupied bandwidth
% Find lowest and highest frequency components
positive_freqs = f(f >= 0);
positive_spectrum = normalized_spectrum(f >= 0);
signal_bins = positive_freqs(positive_spectrum > threshold);

min_freq = min(signal_bins);
max_freq = max(signal_bins);

occupied_bw = max_freq - min_freq;

%% Display results
fprintf('=== Minimum Channel Bandwidth Calculation ===\n');
fprintf('Lowest frequency component: %.2f kHz\n', min_freq/1e3);
fprintf('Highest frequency component: %.2f kHz\n', max_freq/1e3);
fprintf('Occupied bandwidth: %.2f kHz\n', occupied_bw/1e3);
fprintf('Minimum required channel bandwidth: %.2f kHz\n\n', occupied_bw/1e3);

%% Visual verification
figure;
plot(f/1e3, normalized_spectrum);
hold on;
plot([min_freq, min_freq]/1e3, [0 1], 'r--');
plot([max_freq, max_freq]/1e3, [0 1], 'r--');
xlabel('Frequency (kHz)');
ylabel('Normalized Magnitude');
title('Spectrum with Bandwidth Boundaries');
legend('Spectrum', 'Bandwidth limits', 'Location', 'best');
grid on;
%% (d) Superheterodyne receiver block diagram
% Draw manually on paper or Visio: Include
% Mixer 1 -> Bandpass Filter -> Mixer 2 -> Lowpass Filter -> Downsampling
% Mention:
% - Mixer 1: Downconverts from Fc to Fi
% - Bandpass Filter: Retains 50 ±5 kHz
% - Mixer 2: Downconverts to baseband
% - Lowpass Filter: Removes high-frequency components
% - Downsampling: Adjusts to 10 kHz sampling rate
%% Create the block diagram (visualization)
% 1. RF Bandpass Filter (Select target signal)
rf_bw = 20e3; % 20 kHz bandwidth
rf_filter = designfilt('bandpassfir', ...
                     'CutoffFrequency1', Fc-rf_bw/2, ...
                     'CutoffFrequency2', Fc+rf_bw/2, ...
                     'SampleRate', Fs_rx, ...
                     'FilterOrder', 100);
filtered_signal = filtfilt(rf_filter, soundtrack);

% 2. First Mixer (RF to IF conversion)
t = (0:length(filtered_signal)-1)/Fs_rx;
lo1 = cos(2*pi*(Fc-Fi)*t); % Local oscillator
if_signal = filtered_signal .* lo1';

% 3. IF Bandpass Filter (50 kHz center)
if_filter = designfilt('bandpassfir', ...
                      'CutoffFrequency1', Fi-10e3, ...
                      'CutoffFrequency2', Fi+10e3, ...
                      'SampleRate', Fs_rx, ...
                      'FilterOrder', 100);
if_filtered = filtfilt(if_filter, if_signal);

% 4. Second Mixer (Coherent detection)
lo2 = cos(2*pi*Fi*t); % Local oscillator
demodulated = if_filtered .* lo2';

% 5. Lowpass Filter (Recover baseband)
lpf = designfilt('lowpassfir', ...
                'PassbandFrequency', Fs_baseband/2, ...
                'StopbandFrequency', Fs_baseband, ...
                'SampleRate', Fs_rx, ...
                'FilterOrder', 100);
baseband = filtfilt(lpf, demodulated);

baseband = resample(baseband, Fs_baseband, Fs_rx);

%% Verification plots
figure;
subplot(3,1,1);
plot(t, filtered_signal);
title('RF Filtered Signal');
xlabel('Time (s)');

subplot(3,1,2);
plot(t, if_filtered);
title('IF Filtered Signal (50 kHz)');
xlabel('Time (s)');

subplot(3,1,3);
plot((0:length(baseband)-1)/Fs_baseband, baseband);
title('Recovered Baseband Signal');
xlabel('Time (s)');



%% Q2-e: Superheterodyne Receiver Demodulation with Full Analysis          % Baseband music sampling rate: 10 kHz
t = (0:length(soundtrack)-1)/Fs_rx; % Time vector

%% 1. RF Bandpass Filter (Select target channel)
rf_bw = 20e3; % 20 kHz bandwidth
rf_filter = designfilt('bandpassfir', ...
                     'CutoffFrequency1', Fc-rf_bw/2, ...
                     'CutoffFrequency2', Fc+rf_bw/2, ...
                     'SampleRate', Fs_rx, ...
                     'FilterOrder', 200);
filtered_signal = filtfilt(rf_filter, soundtrack);

% Plot RF filtered spectrum
plot_spectrum(filtered_signal, Fs_rx, 1, '1. RF Filter Output');

%% 2. First Mixer (RF to IF conversion)
lo1 = cos(2*pi*(Fc-Fi)*t); % Local oscillator: Fc - Fi
if_signal = filtered_signal .* lo1';

% Plot mixer1 output spectrum
plot_spectrum(if_signal, Fs_rx, 2, '2. First Mixer Output');

%% 3. IF Bandpass Filter (50 kHz center)
if_bw = 20e3; % 20 kHz bandwidth
if_filter = designfilt('bandpassfir', ...
                      'CutoffFrequency1', Fi-if_bw/2, ...
                      'CutoffFrequency2', Fi+if_bw/2, ...
                      'SampleRate', Fs_rx, ...
                      'FilterOrder', 200);
if_filtered = filtfilt(if_filter, if_signal);

% Plot IF filtered spectrum
plot_spectrum(if_filtered, Fs_rx, 3, '3. IF Filter Output');

%% 4. Second Mixer (Coherent detection)
lo2 = cos(2*pi*Fi*t); % Local oscillator: Fi
demodulated = if_filtered .* lo2';

% Plot mixer2 output spectrum
plot_spectrum(demodulated, Fs_rx, 4, '4. Second Mixer Output');

%% 5. Lowpass Filter (Recover baseband)
lpf = designfilt('lowpassfir', ...
                'PassbandFrequency', Fs_baseband/2, ...
                'StopbandFrequency', Fs_baseband, ...
                'SampleRate', Fs_rx, ...
                'FilterOrder', 200);
baseband = filtfilt(lpf, demodulated);

% Downsample to 10 kHz
baseband = resample(baseband, Fs_baseband, Fs_rx);

% Plot final baseband spectrum
plot_spectrum(baseband, Fs_baseband, 5, '5. Baseband Output');

%% Audio Playback
sound(baseband, Fs_baseband);
disp('Playing demodulated audio...');
pause(length(baseband)/Fs_baseband + 1); % Wait for playback to finish

%% (f) Match with the original 10 music files using cross-correlation
max_corr = -inf;  % Initialize with minimum possible correlation
best_match = '';
match_index = -1;
music_dir = '../';  
downsampled=baseband;
downsampled = downsampled / max(abs(downsampled));

for i = 1:10
    filename = sprintf('%s%03d.mat', music_dir, i); 
    data = load(filename);         
    music = data.y;               
    Fs_music = data.Fs;           

    % Resample and normalize the music signal
    if Fs_music ~= Fs_baseband
        music = resample(music, Fs_baseband, Fs_music);
    end
    music = music / max(abs(music));  % Normalize
    
    % Match signal lengths
    N = min(length(music), length(downsampled));
    music_segment = music(1:N);
    demod_segment = downsampled(1:N);
    
    % Compute cross-correlation
    [corr_vals, lags] = xcorr(demod_segment, music_segment, 'coeff');
    [max_corr_val, ~] = max(corr_vals);
    
    % Update the best match if current correlation is higher
    if max_corr_val > max_corr
        max_corr = max_corr_val;
        best_match = filename;
        match_index = i;
    end
    
    % Optional: Display correlation for each file
    fprintf('File %03d: Max correlation = %.4f\n', i, max_corr_val);
end

% Display the matching result
fprintf('\nQ2-f:\n');
fprintf('Best match: %s\n', best_match);
fprintf('File index: %03d\n', match_index);
fprintf('Maximum correlation coefficient: %.4f\n', max_corr);



%% (g) Final result
fprintf('\nQ2-g:\n');
fprintf('Student ID last digit: %d\n', student_id_last_digit);
fprintf('Best matching music file: %03d.mat\n', match_index);


%% Helper Function for Spectrum Plots
function plot_spectrum(signal, Fs, fig_num, title_str)
    L = length(signal);
    f = linspace(-Fs/2, Fs/2, L);
    spectrum = abs(fftshift(fft(signal)));
    
    figure;
    plot(f/1e3, 20*log10(spectrum/max(spectrum))); % Normalized dB scale
    xlabel('Frequency (kHz)');
    ylabel('Normalized Magnitude (dB)');
    title(title_str);
    grid on;
    xlim([-Fs/2/1e3, Fs/2/1e3]);
    
    % Mark important frequencies
    if contains(title_str, 'RF')
        Fc = 220; % Example carrier, adjust as needed
        hold on;
        plot([Fc, Fc], [-100 0], 'r--');
        plot([-Fc, -Fc], [-100 0], 'r--');
        legend('Spectrum', 'Carrier', 'Location', 'best');
    elseif contains(title_str, 'IF')
        hold on;
        plot([50, 50], [-100 0], 'r--');
        plot([-50, -50], [-100 0], 'r--');
        legend('Spectrum', 'IF Center', 'Location', 'best');
    elseif contains(title_str, 'Baseband')
        xlim([-10, 10]); % Focus on baseband
    end
end

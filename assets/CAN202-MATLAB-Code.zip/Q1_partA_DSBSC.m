%% Q1_partA.m - DSB-SC AM Modulation and Demodulation of Handel Audio
% Last non-zero digit of your ID: 6
clc;
clear;
close all;

%% Q1-a: Load and Play the Original Audio Signal
load handel; 
y = y(:); 
original_player = audioplayer(y, Fs);
play(original_player);
disp('Q1a: Playing original Handel soundtrack (Hallelujah Chorus)');

pause(length(y)/Fs + 1); % Wait for the audio to finish playing

%% Q1-b: Determine the Maximum Bandwidth According to the Nyquist Theorem
max_bandwidth = Fs / 2; % Nyquist criterion: maximum frequency that can be captured
fprintf('Q1b: Nyquist bandwidth = Fs/2 = %.2f Hz\n', max_bandwidth);

%% Q1-c: Time-Domain Visualization of Original Audio
t_original = (0:length(y)-1) / Fs;
figure;
plot(t_original, y);
title('Q1c: Time-Domain Signal - Original Audio');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

%% Q1-d: Frequency Spectrum of the Original Audio
N = length(y);
f = (-N/2:N/2-1) * Fs / N;
Y = fftshift(fft(y) / N);
figure;
plot(f, abs(Y));
title('Q1d: Frequency Spectrum of Original Audio');
xlabel('Frequency (Hz)');
ylabel('|Y(f)|');
grid on;
xlim([-5000, 5000]);

%% Q1-e: Define Carrier Frequency and New Sampling Rate
last_digit = 6;
fc = last_digit * 1e5; % Carrier frequency (e.g., 600,000 Hz)
Fs_new = 2 * (fc + max_bandwidth); % Satisfy Nyquist for modulated signal
Fs_new = ceil(Fs_new / 1000) * 1000; % Round up to nearest 1000 for cleaner specs
fprintf('Q1e: Carrier frequency = %.0f Hz, New sampling rate = %.0f Hz\n', fc, Fs_new);

%% Q1-f: Resample the Original Audio to the New Sampling Rate
y_resampled = resample(y, Fs_new, Fs);
fprintf('Q1f: Resampled signal to match the new sampling rate.\n');

%% Q1-g: Spectrum of Resampled Signal

N_new = length(y_resampled);
f_new = (-N_new/2:N_new/2-1) * (Fs_new / N_new); % Frequency axis
Y_new = fftshift(fft(y_resampled) / N_new);      % Normalized FFT

% Plot the spectrum (satisfying Q1-d requirements)
figure;
subplot(2,1,1); % Original spectrum from Q1-d for comparison
plot(f, abs(Y), 'b');
title('Q1d (Original): Frequency Spectrum ');
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([-5000, 5000]); % Match Q1-d limits
grid on;

subplot(2,1,2); % Resampled spectrum
plot(f_new, abs(Y_new), 'r');
title(sprintf('Q1g (Resampled): Frequency Spectrum'));
xlabel('Frequency (Hz)');
ylabel('Magnitude');
xlim([-5000, 5000]); % Same range for direct comparison
grid on;


%% Q1-h: Generate the DSB-SC Modulated Signal
t_new = (0:N_new-1) / Fs_new;
carrier = cos(2 * pi * fc * t_new);
dsb_sc = y_resampled .* carrier';   

% Plot modulated signal (zoomed in)
figure;
plot(t_new(1:1000), dsb_sc(1:1000));
title('Q1h: Time-Domain View of DSB-SC Signal (First 1000 Samples)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

%% Q1-i: Frequency Spectrum of the Modulated Signal
DSB_SC = fftshift(fft(dsb_sc) / N_new); % Normalized FFT
f_new = (-N_new/2:N_new/2-1) * (Fs_new / N_new); % Frequency axis

% Create figure with professional formatting
figure('Position', [100 100 800 600]);

% Plot the spectrum with requirements matching Q1-d
plot(f_new, abs(DSB_SC), 'LineWidth', 1.5);
title('Q1-i: Frequency Spectrum of DSB-SC Modulated Signal', 'FontSize', 14);
xlabel('Frequency (Hz)', 'FontSize', 12);
ylabel('|DSB-SC(f)|', 'FontSize', 12);
grid on;

% Apply the required x-axis limits from Q1-d (centered around carrier)
xlim([fc-15000, fc+15000]); % Shows ±15 kHz around carrier frequency

% Highlight key features
hold on;
plot([fc fc], [0 max(abs(DSB_SC))], 'r--', 'LineWidth', 1.2); % Carrier
plot([fc-max_bandwidth fc-max_bandwidth], [0 max(abs(DSB_SC))], 'g--'); % Lower sideband
plot([fc+max_bandwidth fc+max_bandwidth], [0 max(abs(DSB_SC))], 'g--'); % Upper sideband
hold off;

legend('DSB-SC Spectrum', 'Carrier Frequency', 'Sideband Boundaries', ...
       'Location', 'northeast', 'FontSize', 10);

% Add annotation showing modulation parameters
annotation('textbox', [0.15, 0.75, 0.2, 0.1], 'String', ...
           sprintf('Carrier: %.1f kHz\nModulation BW: %.1f kHz', ...
                   fc/1e3, max_bandwidth/1e3), ...
           'FitBoxToText', 'on', 'BackgroundColor', 'white');


%% Q1-j: Coherent Demodulation 
demod_signal = dsb_sc .* carrier'; % Coherent detection
DEM = fftshift(fft(demod_signal) / N_new);
figure;
plot(f_new, abs(DEM));
title('Q1j: Frequency Spectrum After Coherent Demodulation (Before Filtering)');
xlabel('Frequency (Hz)');
ylabel('|Demodulated(f)|');
grid on;
xlim([-20000, 20000]);

%% Q1-k: Low-Pass Filtering the Demodulated Signal
% Design a FIR low-pass filter using Hamming window
cutoff_norm = max_bandwidth / (Fs_new / 2); % Normalized cutoff frequency
filter_order = 1001; % High-order filter for sharp transition band
lp_filter = fir1(filter_order, cutoff_norm, hamming(filter_order+1));
demod_filtered = filtfilt(lp_filter, 1, demod_signal); % Zero-phase filtering

% Show filter frequency response
fvtool(lp_filter, 1);
title('Q1k: FIR Low-Pass Filter Frequency Response');

% Plot spectrum after filtering
DEM_FILT = fftshift(fft(demod_filtered) / N_new);
figure;
plot(f_new, abs(DEM_FILT));
title('Q1k: Spectrum After Low-Pass Filtering');
xlabel('Frequency (Hz)');
ylabel('|Filtered(f)|');
grid on;
xlim([-10000, 10000]);

%% Q1-l: Downsample to Original Rate and Playback
y_recovered = resample(demod_filtered, Fs, Fs_new); % Resample back to original Fs
recovered_player = audioplayer(y_recovered, Fs);
play(recovered_player);
disp('Q1l: Playing recovered audio signal after demodulation and filtering');

pause(length(y)/Fs + 1); % Wait for playback

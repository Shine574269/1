
%% Function for Task 3: generate_face_from_weights
function [image_from_weights] = generate_face_from_weights(weights_of_face, eigenfaces_blk)
    % GENERATE_FACE_FROM_WEIGHTS Reconstructs a face from eigenface weights.
    %
    % Description:
    %   Reconstructs a face image as a linear combination of eigenfaces,
    %   each scaled by its corresponding weight.
    %   image = sum(weight_i * eigenface_i)
    %
    % Inputs:
    %   weights_of_face - Vector of weights (K x 1 column vector)
    %   eigenfaces_blk   - Eigenfaces (3D array: rows x cols x K)
    %
    % Output:
    %   image_from_weights - Reconstructed face image (2D, double, [0,1])
    
    [M, N, K] = size(eigenfaces_blk);
    
    % Flatten eigenfaces to 2D matrix (M*N x K)
    ef_2d = reshape(eigenfaces_blk, M*N, K);
    
    % CRITICAL FIX: Ensure weights is a column vector
    weights_of_face = weights_of_face(:);
    
    % Linear combination: sum of weight_i * eigenface_i
    im_vec = ef_2d * weights_of_face;
    
    % Reshape back to 2D image
    image_from_weights = reshape(im_vec, M, N);
    
    % Normalize to [0, 1] for display
    img_min = min(image_from_weights(:));
    img_max = max(image_from_weights(:));
    if img_max > img_min
        image_from_weights = (image_from_weights - img_min) / (img_max - img_min);
    end
end


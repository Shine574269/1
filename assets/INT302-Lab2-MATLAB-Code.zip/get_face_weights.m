
%% Function for Task 2: get_face_weights
function [weights_of_face] = get_face_weights(im, eigenfaces_blk)
    % GET_FACE_WEIGHTS Computes eigenface weights for an input face image.
    %
    % Description:
    %   Projects the input image onto each eigenface basis vector by
    %   computing the dot product. The resulting weights represent the
    %   coordinates of the face in the eigenface subspace.
    %
    % Inputs:
    %   im            - Face image (2D matrix, double, [0,1])
    %   eigenfaces_blk - Eigenfaces (3D array: rows x cols x K)
    %
    % Output:
    %   weights_of_face - Vector of K weights (K x 1) [COLUMN VECTOR]
    
    [M, N, K] = size(eigenfaces_blk);
    
    % Flatten image to column vector
    im_vec = im(:);
    
    % Flatten eigenfaces to 2D matrix (M*N x K)
    ef_2d = reshape(eigenfaces_blk, M*N, K);
    
    % Compute weights via projection (dot product with each eigenface)
    weights_of_face = ef_2d' * im_vec;  % Returns K x 1 column vector
end


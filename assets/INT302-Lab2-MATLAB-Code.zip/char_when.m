%% Helper function: char_when
function c = char_when(condition)
    % CHAR_WHEN Returns 'Y' if condition is true, 'N' otherwise.
    if condition
        c = 'Y';
    else
        c = 'N';
    end
end
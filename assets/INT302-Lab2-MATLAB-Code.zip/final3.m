
clear; clc; close all;

% ========================================================================
%% 
% ========================================================================
fig_folder = 'Lab2_Results';
if ~exist(fig_folder, 'dir')
    mkdir(fig_folder);
    fprintf('Created folder: %s\n', fig_folder);
end

%% Load Data
fprintf('========================================\n');
fprintf('Loading data files...\n');
fprintf('========================================\n\n');
load('data_for_eignfaces.mat'); 

fprintf('employees_DB type: %s\n', class(employees_DB));
fprintf('employees_DB size: %d x %d\n', size(employees_DB));
fprintf('Number of employees: %d\n', length(employees_DB));
fprintf('Fields in employees_DB: %s\n', strjoin(fieldnames(employees_DB), ', '));
fprintf('Example: employee(1).id = %d, size(employee(1).weights) = [%d x %d]\n\n', ...
    employees_DB(1).id, size(employees_DB(1).weights,1), size(employees_DB(1).weights,2));

% ========================================================================
%% TASK 1: Orthonormal basis (10 marks)
% ========================================================================
fprintf('========================================\n');
fprintf('TASK 1: Orthonormal basis\n');
fprintf('========================================\n\n');

% Get dimensions of eigenfaces_blk
[M, N, K] = size(eignfaces_blk);  % M=450, N=300, K=100 expected
pixels = M * N;

fprintf('Eigenface dimensions: %d x %d pixels, %d eigenfaces\n', M, N, K);

% Flatten eigenfaces: each column is one eigenface (pixels x K)
ef_2d = reshape(eignfaces_blk, pixels, K);

%% 1.1 Verify orthogonality (5 marks)
fprintf('--- 1.1 Orthogonality Check ---\n');

% Compute dot product matrix K x K
D = ef_2d' * ef_2d;

% Extract diagonal (self dot-products) and off-diagonal
diag_vals = diag(D);
% Set diagonal to 0 to check off-diagonal values
D_off = D - diag(diag_vals);
max_off_diag = max(abs(D_off(:)));

fprintf('Maximum absolute off-diagonal value: %.4e\n', max_off_diag);
if max_off_diag < 1e-10
    fprintf('Conclusion: Eigenfaces ARE orthogonal.\n');
else
    fprintf('Conclusion: Eigenfaces are NOT perfectly orthogonal (numerical tolerance).\n');
end

% Display dot product matrix as image
figure('Name', 'Task_1.1_Dot_Product_Matrix', 'NumberTitle', 'off');
imagesc(D);
colorbar; colormap('jet'); axis image;
title('Task 1.1: Dot Product Matrix of Eigenfaces');
xlabel('Eigenface Index'); ylabel('Eigenface Index');

%% 1.2 Check orthonormality and normalize (5 marks)
fprintf('\n--- 1.2 Orthonormality Check & Normalization ---\n');

% Compute L2 norm of each eigenface
norms = sqrt(sum(ef_2d.^2, 1));  % 1 x K vector

fprintf('Norms of original eigenfaces:\n');
fprintf('  Min:  %.6f\n', min(norms));
fprintf('  Max:  %.6f\n', max(norms));
fprintf('  Mean: %.6f\n', mean(norms));

% Check if orthonormal (all norms close to 1)
if all(abs(norms - 1) < 1e-10)
    fprintf('Eigenfaces ARE already orthonormal.\n');
else
    fprintf('Eigenfaces are NOT orthonormal. Normalizing...\n');
    % Normalize each eigenface by its L2 norm
    ef_norm = ef_2d ./ norms;
    
    % Reshape back to original 3D format
    eigenfaces_blk = reshape(ef_norm, M, N, K);
    
    % Verify normalization
    norms_new = sqrt(sum(ef_norm.^2, 1));
    fprintf('Norms after normalization:\n');
    fprintf('  Min:  %.6f\n', min(norms_new));
    fprintf('  Max:  %.6f\n', max(norms_new));
    fprintf('  Mean: %.6f\n', mean(norms_new));
    fprintf('Normalization complete.\n');
end

% ========================================================================
%% TASK 2: Evaluating the Eigenfaces weights of a face (20 marks)
% ========================================================================
fprintf('\n========================================\n');
fprintf('TASK 2: Evaluating Face Weights\n');
fprintf('========================================\n\n');

%% 2.1 Function description (10 marks)
% The function get_face_weights is defined at the end of this script.

%% 2.2 Compute and plot weights for find_id.jpg (10 marks)
fprintf('--- 2.2 Computing weights for find_id.jpg ---\n');

% Read test image
im_test = imread('find_id.jpg');

% Convert to grayscale if needed
if size(im_test, 3) == 3
    im_test = rgb2gray(im_test);
end

% Convert to double [0, 1]
im_test = im2double(im_test);

% Resize to match eigenface dimensions if needed
fprintf('Image size: %d x %d, Eigenface size: %d x %d\n', ...
    size(im_test,1), size(im_test,2), M, N);
if ~isequal(size(im_test), [M, N])
    im_test = imresize(im_test, [M, N]);
    fprintf('Image resized to %d x %d\n', M, N);
end

% Compute weights using the function
weights_of_face = get_face_weights(im_test, eigenfaces_blk);
fprintf('Size of weights vector: %d x %d\n', size(weights_of_face,1), size(weights_of_face,2));

% Plot the weights
figure('Name', 'Task_2.2_Face_Weights', 'NumberTitle', 'off');
bar(weights_of_face, 'b');
xlabel('Eigenface Index');
ylabel('Weight Value');
title('Task 2.2: Face Weights Projected onto 100 Eigenfaces');
grid on;

fprintf('Weights computed. See figure for bar plot.\n');

% ========================================================================
%% TASK 3: Face generation from its weights (20 marks)
% ========================================================================
fprintf('\n========================================\n');
fprintf('TASK 3: Face Generation from Weights\n');
fprintf('========================================\n\n');

%% 3.1 Function description (10 marks)
% The function generate_face_from_weights is defined at the end of this script.

%% 3.2 Synthesize and display face (3 marks)
fprintf('--- 3.2 Synthesizing face from weights ---\n');

[image_from_weights] = generate_face_from_weights(weights_of_face, eigenfaces_blk);

% Display original vs reconstructed
figure('Name', 'Task_3.2_Original_vs_Reconstructed', 'NumberTitle', 'off');
subplot(1,2,1);
imshow(im_test);
title('Original Face Image');

subplot(1,2,2);
imshow(image_from_weights);
title('Reconstructed Face from 100 Weights');

%% 3.3 Comment on 100 parameters (7 marks)
fprintf('--- 3.3 Comment on dimensionality reduction ---\n');
fprintf('The original face image has %d x %d = %d pixels.\n', M, N, pixels);
fprintf('Yet only 100 parameters (weights) are sufficient because:\n');
fprintf('1. Eigenfaces form a basis for the "face space" from PCA,\n');
fprintf('   capturing the directions of maximum variance in face images.\n');
fprintf('2. Natural face images lie on a low-dimensional manifold within\n');
fprintf('   the high-dimensional pixel space - only meaningful variations\n');
fprintf('   (lighting, pose, expression, identity) require parameters.\n');
fprintf('3. PCA discards redundant correlations between neighboring pixels\n');
fprintf('   while preserving the most significant structural information.\n');
fprintf('4. This compression from %d to 100 dimensions represents approx.\n', pixels);
fprintf('   %.1f%% compression ratio while retaining face identity.\n', (1-100/pixels)*100);

% ========================================================================
%% TASK 4: Recognizing an employee from his/her image (25 marks)
% ========================================================================
fprintf('\n========================================\n');
fprintf('TASK 4: Employee Recognition\n');
fprintf('========================================\n\n');

%% 4.1 Function description (13 marks)
% The function get_employee_ID_from_DB is defined at the end of this script.

%% 4.2 Recognize find_id.jpg (2 marks)
fprintf('--- 4.2 Recognizing find_id.jpg ---\n');

% Recognize the employee ID from the input image
employee_ID = get_employee_ID_from_DB(im_test, employees_DB, eigenfaces_blk);
fprintf('\n========================================\n');
fprintf('Recognized Employee ID for find_id.jpg: %d\n', employee_ID);
fprintf('========================================\n\n');

% Find the corresponding weights in the database and reconstruct the face
[M, N, K] = size(eigenfaces_blk);
found = false;
for i = 1:length(employees_DB)
    if employees_DB(i).id == employee_ID
        % Extract weights of the recognized employee
        db_weights = employees_DB(i).weights;
        % Ensure weights is a column vector
        if size(db_weights, 1) == 1
            db_weights = db_weights';
        end
        % Reconstruct face from weights
        reconstructed_face = generate_face_from_weights(db_weights, eigenfaces_blk);
        found = true;
        break;
    end
end

% Display the input image and the recognized employee face
if found
    figure('Name', 'Task_4.2_Recognized_Employee_Face', 'NumberTitle', 'off');
    
    subplot(1,2,1);
    imshow(im_test);
    title('Input: find_id.jpg');
    
    subplot(1,2,2);
    imshow(reconstructed_face);
    title(sprintf('Recognized Employee ID: %d', employee_ID));
    
    sgtitle('Task 4.2: Face Recognition Result');
else
    fprintf('Warning: Employee ID %d not found in database for reconstruction\n', employee_ID);
end

% ========================================================================
%% TASK 4.3: Adding My Face to Database & Recognition
% ========================================================================
fprintf('\n========================================\n');
fprintf('TASK 4.3: Adding My Face to Database & Recognition\n');
fprintf('========================================\n\n');

%% Step 1: Load original data
fprintf('--- Loading original data ---\n');
load('data_for_eignfaces.mat');
fprintf('Original eigenfaces_blk size: %d x %d x %d\n', size(eignfaces_blk));
fprintf('Original employees_DB size: 1 x %d struct\n', length(employees_DB));

%% Step 2: Read your own photo
fprintf('\n--- Reading my own photo ---\n');
my_photo_file = 'my.jpg';

if ~exist(my_photo_file, 'file')
    error('File "%s" not found! Please put your photo in the current folder.', my_photo_file);
end

im_own = imread(my_photo_file);

if size(im_own, 3) == 3
    im_own_gray = rgb2gray(im_own);
else
    im_own_gray = im_own;
end

im_own_gray = im2double(im_own_gray);

[M, N, K] = size(eigenfaces_blk);
im_own_resized = imresize(im_own_gray, [M, N]);

fprintf('My photo size after preprocessing: %d x %d\n', M, N);

figure('Name', 'Task_4.3_My_Processed_Photo', 'NumberTitle', 'off');
imshow(im_own_resized);
title('My Photo (Processed)');

%% Step 3: Compute weights for my photo
fprintf('\n--- Computing weights for my photo ---\n');

ef_2d = reshape(eignfaces_blk, M*N, K);

norms = sqrt(sum(ef_2d.^2, 1));
if any(abs(norms - 1) > 1e-10)
    fprintf('Normalizing eigenfaces...\n');
    ef_2d = ef_2d ./ norms;
    eignfaces_blk = reshape(ef_2d, M, N, K);
end

im_flat = im_own_resized(:);
weights_own = ef_2d' * im_flat;

figure('Name', 'Task_4.3_My_Face_Weights', 'NumberTitle', 'off');
bar(weights_own);
xlabel('Eigenface Index');
ylabel('Weight Value');
title('My Face Weights on 100 Eigenfaces');
grid on;

fprintf('Weights computed: size = %d x %d\n', size(weights_own,1), size(weights_own,2));

%% Step 4: Add my face to database at random position
fprintf('\n--- Adding my face to database at random position ---\n');

rng('shuffle');
random_index = randi([1, 100]);
fprintf('Randomly selected index: %d\n', random_index);

old_id = employees_DB(random_index).id;
fprintf('Replacing employee ID %d at position %d\n', old_id, random_index);

new_id = 111;

%% Step 5: Create updated database
fprintf('\n--- Creating updated database ---\n');

eigenfaces_blk_new = eigenfaces_blk;
employees_DB_new = employees_DB;

employees_DB_new(random_index).id = new_id;
employees_DB_new(random_index).weights = weights_own';

fprintf('Updated employee at index %d:\n', random_index);
fprintf('  Old ID: %d\n', old_id);
fprintf('  New ID: %d\n', new_id);
fprintf('  Weights size: %d x %d\n', size(employees_DB_new(random_index).weights,1), ...
                                    size(employees_DB_new(random_index).weights,2));

%% Step 6: Save updated database
fprintf('\n--- Saving updated database ---\n');

new_mat_filename = 'data_for_eignfaces_with_myface.mat';
save(new_mat_filename, 'eigenfaces_blk_new', 'employees_DB_new', 'im_own_resized', 'random_index', 'new_id');
fprintf('Saved new database to: %s\n', new_mat_filename);

eigenfaces_blk = eigenfaces_blk_new;
employees_DB = employees_DB_new;
save('data_for_eignfaces_updated.mat', 'eigenfaces_blk', 'employees_DB');
fprintf('Saved updated database to: data_for_eignfaces_updated.mat\n');

%% Step 7: Verify recognition with updated database
fprintf('\n========================================\n');
fprintf('VERIFICATION: Testing recognition with updated database\n');
fprintf('========================================\n\n');

recognized_ID = get_employee_ID_from_DB(im_own_resized, employees_DB, eigenfaces_blk);

fprintf('\n--- Recognition Result ---\n');
fprintf('My actual ID in database: %d (at index %d)\n', new_id, random_index);
fprintf('Recognized ID: %d\n', recognized_ID);

if recognized_ID == new_id
    fprintf('✓ SUCCESS! My face was correctly recognized!\n');
else
    fprintf('✗ FAILED! Recognized as ID %d instead of %d\n', recognized_ID, new_id);
    
    my_weights = get_face_weights(im_own_resized, eigenfaces_blk);
    distances = zeros(length(employees_DB), 1);
    for i = 1:length(employees_DB)
        db_weights = employees_DB(i).weights;
        if size(db_weights, 1) == 1
            db_weights = db_weights';
        end
        distances(i) = norm(my_weights - db_weights);
    end
    
    [sorted_dist, sorted_idx] = sort(distances);
    fprintf('\nTop 5 closest matches:\n');
    for i = 1:min(5, length(sorted_idx))
        fprintf('Rank %d: ID %d (Distance: %.4f)\n', i, ...
                employees_DB(sorted_idx(i)).id, sorted_dist(i));
    end
end

%% Step 8: Generate comparison visualization
fprintf('\n--- Generating comparison visualization ---\n');
% 
% for i = 1:length(employees_DB)
%     if employees_DB(i).id == new_id
%         db_weights = employees_DB(i).weights;
%         if size(db_weights, 1) == 1
%             db_weights = db_weights';
%         end
%         reconstructed_face = generate_face_from_weights(db_weights, eigenfaces_blk);
%         
%         figure('Name', 'Task_4.3_Final_Comparison', 'NumberTitle', 'off', ...
%                'Position', [100, 100, 1200, 400]);
%         
%         subplot(1,3,1);
%         imshow(im_own_resized);
%         title('My Original Photo');
%         
%         subplot(1,3,2);
%         imshow(reconstructed_face);
%         title(sprintf('Reconstructed from DB\n(Employee ID: %d)', new_id));
%         
%         subplot(1,3,3);
%         imshowpair(im_own_resized, reconstructed_face, 'diff');
%         title('Difference Image');
%         
%         sgtitle('Task 4.3: Verification of My Face in Database');
%         break;
%     end
% end

% ========================================================================
%% TASK 5: Robustness of the developed algorithm (30 marks)
% ========================================================================
fprintf('\n========================================\n');
fprintf('TASK 5: Robustness Assessment\n');
fprintf('========================================\n\n');

% Use im_test (find_id.jpg) as the base image for robustness tests
correct_ID = employee_ID;  % The ID we found in Task 4.2
fprintf('Correct ID for find_id.jpg: %d\n\n', correct_ID);

%% 5.1 AWGN robustness (7 marks)
fprintf('--- 5.1 Robustness against AWGN ---\n');
sigma_values = [5, 20, 60, 100, 150];
awgn_recognized = zeros(size(sigma_values));

fprintf('  sigma    | Recognized\n');
fprintf('  ---------|-----------\n');

for i = 1:length(sigma_values)
    sigma = sigma_values(i);
    
    % Add AWGN (sigma is pixel intensity, convert to double range [0,1])
    noise = (sigma / 255) * randn(size(im_test));
    im_noisy = im_test + noise;
    im_noisy = max(0, min(1, im_noisy));  % Clip to [0,1]
    
    % Display noisy image for first case
    if i == 1
        figure('Name', 'Task_5.1_AWGN_Example', 'NumberTitle', 'off');
        subplot(1,2,1); imshow(im_test); title('Original');
        subplot(1,2,2); imshow(im_noisy); title(sprintf('AWGN \\sigma=%d', sigma));
    end
    
    try
        ID_recognized = get_employee_ID_from_DB(im_noisy, employees_DB, eigenfaces_blk);
        awgn_recognized(i) = (ID_recognized == correct_ID);
    catch
        awgn_recognized(i) = false;
    end
    
    fprintf('  %3d      |     %s\n', sigma, char_when(awgn_recognized(i)));
end

%% 5.2 Salt & Pepper noise robustness (7 marks)
fprintf('\n--- 5.2 Robustness against Salt & Pepper noise ---\n');
density_values = [0.01, 0.20, 0.40, 0.60, 0.80];
sp_recognized = zeros(size(density_values));

fprintf('  density   | Recognized\n');
fprintf('  ----------|-----------\n');

for i = 1:length(density_values)
    density = density_values(i);
    
    % Add salt & pepper noise
    im_noisy = imnoise(im_test, 'salt & pepper', density);
    
    % Display noisy image for first case
    if i == 1
        figure('Name', 'Task_5.2_Salt_Pepper_Example', 'NumberTitle', 'off');
        imshow(im_noisy); title(sprintf('Salt & Pepper density=%.0f%%', density*100));
    end
    
    try
        ID_recognized = get_employee_ID_from_DB(im_noisy, employees_DB, eigenfaces_blk);
        sp_recognized(i) = (ID_recognized == correct_ID);
    catch
        sp_recognized(i) = false;
    end
    
    fprintf('  %.0f%%       |     %s\n', density*100, char_when(sp_recognized(i)));
end

%% 5.3 Luminance robustness (10 marks)
fprintf('\n--- 5.3 Robustness against Luminance Change ---\n');

% rho > 1 (brighter)
rho_high = [1.001, 1.01, 1.1, 1.2, 1.3];
lum_high_recognized = zeros(size(rho_high));

fprintf('  rho (high)| Recognized\n');
fprintf('  ----------|-----------\n');

for i = 1:length(rho_high)
    rho = rho_high(i);
    im_bright = im_test * rho;
    im_bright = max(0, min(1, im_bright));
    
    try
        ID_recognized = get_employee_ID_from_DB(im_bright, employees_DB, eigenfaces_blk);
        lum_high_recognized(i) = (ID_recognized == correct_ID);
    catch
        lum_high_recognized(i) = false;
    end
    
    fprintf('  %.3f     |     %s\n', rho, char_when(lum_high_recognized(i)));
end

% rho < 1 (darker)
rho_low = [0.99, 0.9, 0.85, 0.8, 0.7];
lum_low_recognized = zeros(size(rho_low));

fprintf('\n  rho (low) | Recognized\n');
fprintf('  ----------|-----------\n');

for i = 1:length(rho_low)
    rho = rho_low(i);
    im_dark = im_test * rho;
    im_dark = max(0, min(1, im_dark));
    
    try
        ID_recognized = get_employee_ID_from_DB(im_dark, employees_DB, eigenfaces_blk);
        lum_low_recognized(i) = (ID_recognized == correct_ID);
    catch
        lum_low_recognized(i) = false;
    end
    
    fprintf('  %.2f      |     %s\n', rho, char_when(lum_low_recognized(i)));
end

%% 5.4 Improvement solutions (6 marks)
fprintf('\n--- 5.4 Possible solutions to improve robustness ---\n');
fprintf('1. Preprocessing with Median Filtering: Effective for salt & pepper\n');
fprintf('   noise removal before feature extraction.\n');
fprintf('2. Gaussian Smoothing: Reduces AWGN effect while preserving edges.\n');
fprintf('3. Histogram Equalization: Normalizes lighting variations, making\n');
fprintf('   the system invariant to luminance changes.\n');
fprintf('4. Illumination Normalization: Techniques like homomorphic filtering\n');
fprintf('   or local normalization can handle non-uniform lighting.\n');
fprintf('5. Data Augmentation in Database: Include faces under various\n');
fprintf('   lighting and noise conditions for robust matching.\n');
fprintf('6. Robust Distance Metrics: Use cosine distance (angle-based) instead\n');
fprintf('   of Euclidean for better illumination invariance.\n');

% ========================================================================
%% TASK 6: Histogram Equalization (15 marks)
% ========================================================================
fprintf('\n========================================\n');
fprintf('TASK 6: Histogram Equalization\n');
fprintf('========================================\n\n');

% Read low dynamic range image
img_low = imread('lenna512_low_dynamic_range.bmp');

% Convert to grayscale if needed
if size(img_low, 3) == 3
    img_low = rgb2gray(img_low);
end

img_low = im2double(img_low);
fprintf('Original image size: %d x %d\n', size(img_low,1), size(img_low,2));

% Apply custom histogram equalization
img_eq = my_histogram_equalization(img_low);

% Display results
figure('Name', 'Task_6_Histogram_Equalization', 'NumberTitle', 'off');

% Original image
subplot(2,3,1);
imshow(img_low);
title('Original Low Dynamic Range Image');

% Equalized image
subplot(2,3,2);
imshow(img_eq);
title('After Histogram Equalization');

% Display side by side comparison
subplot(2,3,3);
imshowpair(img_low, img_eq, 'montage');
title('Side-by-Side Comparison');

% Histogram of original
subplot(2,3,4);
histogram(img_low, 256, 'FaceColor', 'b', 'EdgeColor', 'none');
xlim([0 1]);
title('Histogram - Original');
xlabel('Intensity'); ylabel('Frequency');

% Histogram of equalized
subplot(2,3,5);
histogram(img_eq, 256, 'FaceColor', 'r', 'EdgeColor', 'none');
xlim([0 1]);
title('Histogram - Equalized');
xlabel('Intensity'); ylabel('Frequency');

% Cumulative histogram comparison
subplot(2,3,6);
cdf_orig = cumsum(histcounts(img_low, 256, 'Normalization', 'probability'));
cdf_eq = cumsum(histcounts(img_eq, 256, 'Normalization', 'probability'));
plot(linspace(0,1,256), cdf_orig, 'b-', 'LineWidth', 1.5); hold on;
plot(linspace(0,1,256), cdf_eq, 'r-', 'LineWidth', 1.5); hold off;
title('CDF Comparison');
xlabel('Intensity'); ylabel('Cumulative Probability');
legend('Original', 'Equalized', 'Location', 'southeast');
grid on;

fprintf('Histogram equalization complete. See figure for results.\n');
fprintf('Findings:\n');
fprintf('- Original histogram is concentrated in a narrow range (low contrast).\n');
fprintf('- Equalized histogram is spread across the full [0,1] range.\n');
fprintf('- The CDF of equalized image is approximately linear.\n');
fprintf('- Result: Enhanced contrast with better visibility of details.\n');

% ========================================================================
%% SAVE ALL FIGURES TO FOLDER
% ========================================================================

fprintf('\n========================================\n');
fprintf('SAVING ALL FIGURES TO FOLDER: %s\n', fig_folder);
fprintf('========================================\n');

% 获取所有打开的figure句柄
all_figs = findall(0, 'Type', 'figure');

% 遍历并保存每个figure
for fig = all_figs'
    % 获取figure的Name属性
    fig_name = get(fig, 'Name');
    
    % 如果Name为空，使用默认名称
    if isempty(fig_name)
        fig_name = sprintf('Figure_%d', fig.Number);
    end
    
    % 生成完整的文件路径
    filename = fullfile(fig_folder, sprintf('%s.png', fig_name));
    
    % 保存图片
    saveas(fig, filename);
    fprintf('Saved: %s\n', filename);
end

fprintf('\n========================================\n');
fprintf('ALL TASKS COMPLETED SUCCESSFULLY\n');
fprintf('ALL FIGURES SAVED TO: %s\n', fig_folder);
fprintf('========================================\n');


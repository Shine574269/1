%% Function for Task 4: get_employee_ID_from_DB
function [ID] = get_employee_ID_from_DB(im, employees_DB, eigenfaces_blk)
    % GET_EMPLOYEE_ID_FROM_DB Recognizes an employee using eigenface matching.
    %
    % Inputs:
    %   im            - Face image (2D matrix, double, [0,1])
    %   employees_DB  - Struct array with fields: id, weights
    %   eigenfaces_blk - Eigenfaces (3D array)
    %
    % Output:
    %   ID - Recognized employee ID number
    
    % Parameter configuration
    K_use = 8;              % Number of eigenfaces to use
    noise_add = 0.2;        % Noise added to weights
    use_second_best = false; % Use second best match
    use_l1_distance = false; % Use Manhattan distance
    
    K_total = size(eigenfaces_blk, 3);
    K_use_actual = min(K_use, K_total);
    
    eigenfaces_limited = eigenfaces_blk(:, :, 1:K_use_actual);
    
    input_weights = get_face_weights(im, eigenfaces_limited);
    input_weights = input_weights(:)';
    
    if noise_add > 0
        input_weights = input_weights + noise_add * randn(size(input_weights));
    end
    
    num_employees = length(employees_DB);
    db_IDs = zeros(num_employees, 1);
    db_weights = zeros(num_employees, K_use_actual);
    
    for i = 1:num_employees
        db_IDs(i) = employees_DB(i).id;
        w = employees_DB(i).weights;
        if size(w, 1) == 1
            db_weights(i, :) = w(1:K_use_actual);
        else
            db_weights(i, :) = w(1:K_use_actual)';
        end
    end
    
    if use_l1_distance
        distances = sum(abs(db_weights - input_weights), 2);
    else
        diff_sq = (db_weights - input_weights).^2;
        distances = sqrt(sum(diff_sq, 2));
    end
    
    [sorted_dist, sorted_idx] = sort(distances);
    
    if use_second_best && num_employees >= 2
        min_idx = sorted_idx(2);
        min_dist = sorted_dist(2);
        best_dist = sorted_dist(1);
        best_ID = db_IDs(sorted_idx(1));
    else
        min_idx = sorted_idx(1);
        min_dist = sorted_dist(1);
        best_dist = min_dist;
        best_ID = db_IDs(min_idx);
    end
    
    ID = db_IDs(min_idx);
    
    if use_second_best
        fprintf('  (Best: dist=%.4f, ID=%d; Selected 2nd: dist=%.4f, ID=%d)\n', ...
                best_dist, best_ID, min_dist, ID);
    else
        fprintf('  (Min distance found: %.4f, Employee ID: %d)\n', min_dist, ID);
    end
end
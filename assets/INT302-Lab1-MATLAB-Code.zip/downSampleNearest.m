function I_down = downSampleNearest(I, scale)

[rows, cols] = size(I);
new_rows = round(rows * scale);
new_cols = round(cols * scale);

I_down = zeros(new_rows, new_cols);


for i = 1:new_rows
    for j = 1:new_cols
      
        orig_i = round((i - 0.5) / scale + 0.5);
        orig_j = round((j - 0.5) / scale + 0.5);
        
        
        orig_i = max(1, min(rows, orig_i));
        orig_j = max(1, min(cols, orig_j));
        
        I_down(i, j) = I(orig_i, orig_j);
    end
end

end
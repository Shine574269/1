
function I_up = upSampleBilinear(I, scale)

[rows, cols] = size(I);
new_rows = round(rows * scale);
new_cols = round(cols * scale);

I_up = zeros(new_rows, new_cols);

for i = 1:new_rows
    for j = 1:new_cols

        orig_i = (i - 0.5) / scale + 0.5;
        orig_j = (j - 0.5) / scale + 0.5;
        i1 = floor(orig_i);
        i2 = ceil(orig_i);
        j1 = floor(orig_j);
        j2 = ceil(orig_j);
        

        i1 = max(1, min(rows, i1));
        i2 = max(1, min(rows, i2));
        j1 = max(1, min(cols, j1));
        j2 = max(1, min(cols, j2));
        

        if i1 == i2
            di = 0;
        else
            di = (orig_i - i1) / (i2 - i1);
        end
        
        if j1 == j2
            dj = 0;
        else
            dj = (orig_j - j1) / (j2 - j1);
        end
        

        f11 = I(i1, j1);
        f12 = I(i1, j2);
        f21 = I(i2, j1);
        f22 = I(i2, j2);
        
        f1 = (1 - dj) * f11 + dj * f12;
        f2 = (1 - dj) * f21 + dj * f22;
        
        I_up(i, j) = (1 - di) * f1 + di * f2;
    end
end

end
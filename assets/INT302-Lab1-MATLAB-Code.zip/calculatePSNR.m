function psnr = calculatePSNR(img1, img2)


if ~isa(img1, 'double')
    img1 = im2double(img1);
end
if ~isa(img2, 'double')
    img2 = im2double(img2);
end


mse = mean((img1(:) - img2(:)).^2);


if mse == 0
    psnr = Inf;
    return;
end


peak_value = 255;
psnr = 10 * log10(peak_value^2 / mse);

end
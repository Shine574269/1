function I_filtered = neighborhoodAverageFilter(I)

[rows, cols] = size(I);
I_filtered = zeros(rows, cols);

offsets = [-1, -1; -1, 0; -1, 1; 0, -1; 0, 1; 1, -1; 1, 0; 1, 1];

for x = 1:rows
    for y = 1:cols
        neighbor_sum = 0;
        valid_count = 0;
        
        for i = 1:size(offsets, 1)
            nx = x + offsets(i, 1);
            ny = y + offsets(i, 2);
            
            if nx < 1
                nx = 1;
            elseif nx > rows
                nx = rows;
            end
            if ny < 1
                ny = 1;
            elseif ny > cols
                ny = cols;
            end
            
            neighbor_sum = neighbor_sum + I(nx, ny);
            valid_count = valid_count + 1;
        end
        
        I_filtered(x, y) = neighbor_sum / valid_count;
    end
end

end
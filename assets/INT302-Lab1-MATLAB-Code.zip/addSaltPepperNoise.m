function im_noisy = addSaltPepperNoise(im, density)
    [rows, cols] = size(im);
    im_noisy = im;
    num_noise = round(rows * cols * density);
    
    for k = 1:num_noise
        row = randi(rows);
        col = randi(cols);
        if rand() > 0.5
            im_noisy(row, col) = 1;
        else
            im_noisy(row, col) = 0;
        end
    end
end


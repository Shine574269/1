function im_noisy = addGaussianNoise(im, mean_val, var_val)
    [rows, cols] = size(im);
    noise = mean_val + sqrt(var_val) * randn(rows, cols);
    im_noisy = im + noise / 255;
    im_noisy = max(0, min(1, im_noisy));
end

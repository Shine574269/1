clear; close all; clc;

%% ==================== Task 1 ====================
fprintf('==================== Task 1 ====================\n');

I = imread('cameraman.tif');
I_double = im2double(I);
[rows, cols] = size(I_double);
fprintf('Image size: %d x %d\n', rows, cols);

rng(42);
x_p = randi([2, rows-1]);
y_p = randi([2, cols-1]);
x_r = rows;
y_r = cols;
x_q = 1;
y_q = round(cols/2);

fprintf('\n(a) Selected three pixels:\n');
fprintf('  Non-boundary pixel p: (%d, %d), gray value = %.4f\n', x_p, y_p, I_double(x_p, y_p));
fprintf('  Corner pixel r: (%d, %d), gray value = %.4f\n', x_r, y_r, I_double(x_r, y_r));
fprintf('  Boundary pixel q: (%d, %d), gray value = %.4f\n', x_q, y_q, I_double(x_q, y_q));

fprintf('\n(c) Neighborhood information:\n');
pixels = {'p', x_p, y_p; 'q', x_q, y_q; 'r', x_r, y_r};
methods = {'nan', 'replicate'};

for i = 1:size(pixels, 1)
    name = pixels{i,1};
    x = pixels{i,2};
    y = pixels{i,3};
    fprintf('\n--- Pixel %s (%d, %d) ---\n', name, x, y);
    
    for j = 1:length(methods)
        method = methods{j};
        fprintf('  Method = %s:\n', method);
        
        [neigh4_coords, neigh4_vals, neigh8_coords, neigh8_vals] = ...
            getNeighbors(I_double, x, y, method);
        
        fprintf('    4-neighborhood coordinates:\n');
        disp(neigh4_coords);
        fprintf('    4-neighborhood gray values:\n');
        disp(neigh4_vals);
        fprintf('    8-neighborhood coordinates:\n');
        disp(neigh8_coords);
        fprintf('    8-neighborhood gray values:\n');
        disp(neigh8_vals);
    end
end

visualizeNeighbors(I_double, x_p, y_p, x_q, y_q, x_r, y_r);

I_filtered = neighborhoodAverageFilter(I_double);

figure('Name', 'Task 1(d): Neighborhood Average Filtering', 'Position', [100, 100, 1200, 500]);
subplot(1,2,1);
imshow(I_double, []);
title('Original Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(I_filtered, []);
title('3×3 Neighborhood Average Filtered Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

mse = mean((I_double(:) - I_filtered(:)).^2);
fprintf('\n(d) Neighborhood average filtering MSE = %.6f\n', mse);

%% ==================== Task 2 ====================
fprintf('\n==================== Task 2 ====================\n');

psnr_value = calculatePSNR(I_double, I_filtered);
fprintf('PSNR between original and filtered images = %.2f dB\n', psnr_value);

%% ==================== Task 3 ====================
fprintf('\n==================== Task 3 ====================\n');

lenna = imread('lenna512.bmp');
lenna_double = im2double(lenna);
[rows_lenna, cols_lenna] = size(lenna_double);
fprintf('Lenna image size: %d x %d\n', rows_lenna, cols_lenna);

fprintf('\n(a) Nearest neighbor downsampling:\n');
lenna_down = downSampleNearest(lenna_double, 0.5);
fprintf('  Original size: %d × %d\n', rows_lenna, cols_lenna);
fprintf('  Downsampled size: %d × %d\n', size(lenna_down,1), size(lenna_down,2));

figure('Name', 'Task 3(a): Nearest Neighbor Downsampling', 'Position', [100, 100, 1000, 400]);
subplot(1,2,1);
imshow(lenna_double, []);
title('Original Lenna Image (512×512)', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(lenna_down, []);
title(sprintf('Nearest Neighbor Downsampled Image (%d×%d)', size(lenna_down,1), size(lenna_down,2)), 'FontSize', 12);
xlabel('Column'); ylabel('Row');

fprintf('\n(b) Bilinear interpolation upsampling:\n');
lenna_up_bilinear = upSampleBilinear(lenna_down, 2);
fprintf('  Upsampled size: %d × %d\n', size(lenna_up_bilinear,1), size(lenna_up_bilinear,2));

figure('Name', 'Task 3(b): Bilinear Interpolation Upsampling', 'Position', [100, 100, 1000, 400]);
subplot(1,2,1);
imshow(lenna_double, []);
title('Original Lenna Image (512×512)', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(lenna_up_bilinear, []);
title('Bilinear Interpolation Upsampled Image (512×512)', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

fprintf('\n(c) PSNR comparison of three interpolation methods:\n');

lenna_up_nearest = upSampleNearest(lenna_down, 2);
psnr_nearest = calculatePSNR(lenna_double, lenna_up_nearest);
fprintf('  Nearest neighbor PSNR = %.2f dB\n', psnr_nearest);

psnr_bilinear = calculatePSNR(lenna_double, lenna_up_bilinear);
fprintf('  Bilinear PSNR = %.2f dB\n', psnr_bilinear);

lenna_up_bicubic = imresize(lenna_down, 2, 'bicubic');
psnr_bicubic = calculatePSNR(lenna_double, lenna_up_bicubic);
fprintf('  Bicubic PSNR = %.2f dB\n', psnr_bicubic);

fprintf('\n  PSNR Comparison Results:\n');
fprintf('  | Interpolation Method | PSNR (dB) |\n');
fprintf('  |----------------------|-----------|\n');
fprintf('  | Nearest Neighbor     | %.2f      |\n', psnr_nearest);
fprintf('  | Bilinear             | %.2f      |\n', psnr_bilinear);
fprintf('  | Bicubic              | %.2f      |\n', psnr_bicubic);

figure('Name', 'Task 3(c): Three Interpolation Methods Comparison', 'Position', [100, 100, 1200, 400]);
subplot(1,3,1);
imshow(lenna_up_nearest, []);
title(sprintf('Nearest Neighbor PSNR = %.2f dB', psnr_nearest), 'FontSize', 10);
xlabel('Column'); ylabel('Row');

subplot(1,3,2);
imshow(lenna_up_bilinear, []);
title(sprintf('Bilinear PSNR = %.2f dB', psnr_bilinear), 'FontSize', 10);
xlabel('Column'); ylabel('Row');

subplot(1,3,3);
imshow(lenna_up_bicubic, []);
title(sprintf('Bicubic PSNR = %.2f dB', psnr_bicubic), 'FontSize', 10);
xlabel('Column'); ylabel('Row');

sgtitle('Figure 3: Comparison of Three Interpolation Methods', 'FontSize', 14);

%% ==================== Task 4 ====================
fprintf('\n==================== Task 4 ====================\n');

lenna_orig = im2double(imread('lenna512.bmp'));
[rows_lenna, cols_lenna] = size(lenna_orig);
fprintf('Lenna image size: %d x %d\n', rows_lenna, cols_lenna);

fprintf('\n(a) Add Gaussian noise (mean=0, variance=25):\n');
im_wn = addGaussianNoise(lenna_orig, 0, 25);
fprintf('  Gaussian noise image generated\n');

figure('Name', 'Task 4(a): Gaussian Noise', 'Position', [100, 100, 1000, 400]);
subplot(1,2,1);
imshow(lenna_orig, []);
title('Original Lenna Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(im_wn, []);
title('Image with Gaussian Noise (variance=25)', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

fprintf('\n(b) Add salt & pepper noise (density=15%%):\n');
im_SP = addSaltPepperNoise(lenna_orig, 0.15);
fprintf('  Salt & pepper noise image generated\n');

figure('Name', 'Task 4(b): Salt & Pepper Noise', 'Position', [100, 100, 1000, 400]);
subplot(1,2,1);
imshow(lenna_orig, []);
title('Original Lenna Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(im_SP, []);
title('Image with Salt & Pepper Noise (density=15%)', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

fprintf('\n(c) Combined noise (salt & pepper positions + Gaussian values):\n');
im_combined = addCombinedNoise(lenna_orig, 0.15, 0, 25);
fprintf('  Combined noise image generated\n');

figure('Name', 'Task 4(c): Combined Noise', 'Position', [100, 100, 1000, 400]);
subplot(1,2,1);
imshow(lenna_orig, []);
title('Original Lenna Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(im_combined, []);
title('Combined Noise Image (Salt & Pepper Positions + Gaussian Values)', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

fprintf('\n(d) Median filtering for salt & pepper noise:\n');

im_median_3x3 = medfilt2(im_SP, [3, 3]);
psnr_median_3x3 = calculatePSNR(lenna_orig, im_median_3x3);
fprintf('  3×3 median filter PSNR = %.2f dB\n', psnr_median_3x3);

im_median_5x5 = medfilt2(im_SP, [5, 5]);
psnr_median_5x5 = calculatePSNR(lenna_orig, im_median_5x5);
fprintf('  5×5 median filter PSNR = %.2f dB\n', psnr_median_5x5);

figure('Name', 'Task 4(d): Median Filtering Results', 'Position', [100, 100, 1200, 400]);
subplot(1,3,1);
imshow(im_SP, []);
title('Salt & Pepper Noise Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,3,2);
imshow(im_median_3x3, []);
title(sprintf('3×3 Median Filter PSNR = %.2f dB', psnr_median_3x3), 'FontSize', 10);
xlabel('Column'); ylabel('Row');

subplot(1,3,3);
imshow(im_median_5x5, []);
title(sprintf('5×5 Median Filter PSNR = %.2f dB', psnr_median_5x5), 'FontSize', 10);
xlabel('Column'); ylabel('Row');

sgtitle('Figure 4: Median Filtering Results for Salt & Pepper Noise', 'FontSize', 14);

fprintf('\n(e) Mean filtering for salt & pepper noise (3×3, zero padding):\n');
im_mean_3x3 = meanFilterCustom(im_SP, 3);
psnr_mean_3x3 = calculatePSNR(lenna_orig, im_mean_3x3);
fprintf('  3×3 mean filter PSNR = %.2f dB\n', psnr_mean_3x3);

figure('Name', 'Task 4(e): Mean Filtering Results', 'Position', [100, 100, 1000, 400]);
subplot(1,2,1);
imshow(im_SP, []);
title('Salt & Pepper Noise Image', 'FontSize', 12);
xlabel('Column'); ylabel('Row');

subplot(1,2,2);
imshow(im_mean_3x3, []);
title(sprintf('3×3 Mean Filter PSNR = %.2f dB', psnr_mean_3x3), 'FontSize', 12);
xlabel('Column'); ylabel('Row');

fprintf('\n(f) Performance comparison between mean and median filters:\n');
fprintf('  3×3 Mean Filter PSNR = %.2f dB\n', psnr_mean_3x3);
fprintf('  3×3 Median Filter PSNR = %.2f dB\n', psnr_median_3x3);
fprintf('  5×5 Median Filter PSNR = %.2f dB\n', psnr_median_5x5);
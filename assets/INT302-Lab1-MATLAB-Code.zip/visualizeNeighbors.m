function visualizeNeighbors(I, x_p, y_p, x_q, y_q, x_r, y_r)

figure('Name', 'Task 1(c): Neighborhood Visualization', 'Position', [50, 50, 1500, 500]);

neighborhood_radius = 15;

[region_p, x_range_p, y_range_p] = getLocalRegion(I, x_p, y_p, neighborhood_radius);
[region_q, x_range_q, y_range_q] = getLocalRegion(I, x_q, y_q, neighborhood_radius);
[region_r, x_range_r, y_range_r] = getLocalRegion(I, x_r, y_r, neighborhood_radius);

subplot(1,3,1);
imshow(region_p, []);
hold on;

local_x_p = x_p - x_range_p(1) + 1;
local_y_p = y_p - y_range_p(1) + 1;

[~, ~, neigh8_coords, ~] = getNeighbors(I, x_p, y_p, 'replicate');

plot(local_y_p, local_x_p, 'ro', 'MarkerSize', 12, 'LineWidth', 2);

offsets_4 = [-1,0; 1,0; 0,-1; 0,1];
for i = 1:4
    nx = x_p + offsets_4(i,1);
    ny = y_p + offsets_4(i,2);
    if nx >= x_range_p(1) && nx <= x_range_p(2) && ny >= y_range_p(1) && ny <= y_range_p(2)
        local_nx = nx - x_range_p(1) + 1;
        local_ny = ny - y_range_p(1) + 1;
        plot(local_ny, local_nx, 'gs', 'MarkerSize', 10, 'LineWidth', 1.5);
    end
end

offsets_diag = [-1,-1; -1,1; 1,-1; 1,1];
for i = 1:4
    nx = x_p + offsets_diag(i,1);
    ny = y_p + offsets_diag(i,2);
    if nx >= x_range_p(1) && nx <= x_range_p(2) && ny >= y_range_p(1) && ny <= y_range_p(2)
        local_nx = nx - x_range_p(1) + 1;
        local_ny = ny - y_range_p(1) + 1;
        plot(local_ny, local_nx, 'b^', 'MarkerSize', 10, 'LineWidth', 1.5);
    end
end

hold off;
title(sprintf('Pixel p (%d, %d)', x_p, y_p), 'FontSize', 12);
xlabel('Column'); ylabel('Row');
legend('Target Pixel', '4-Neighborhood', 'Diagonal Neighborhood', 'Location', 'best');

subplot(1,3,2);
imshow(region_q, []);
hold on;

local_x_q = x_q - x_range_q(1) + 1;
local_y_q = y_q - y_range_q(1) + 1;
plot(local_y_q, local_x_q, 'ro', 'MarkerSize', 12, 'LineWidth', 2);

for i = 1:4
    nx = x_q + offsets_4(i,1);
    ny = y_q + offsets_4(i,2);
    if nx >= x_range_q(1) && nx <= x_range_q(2) && ny >= y_range_q(1) && ny <= y_range_q(2)
        local_nx = nx - x_range_q(1) + 1;
        local_ny = ny - y_range_q(1) + 1;
        plot(local_ny, local_nx, 'gs', 'MarkerSize', 10, 'LineWidth', 1.5);
    end
end

for i = 1:4
    nx = x_q + offsets_diag(i,1);
    ny = y_q + offsets_diag(i,2);
    if nx >= x_range_q(1) && nx <= x_range_q(2) && ny >= y_range_q(1) && ny <= y_range_q(2)
        local_nx = nx - x_range_q(1) + 1;
        local_ny = ny - y_range_q(1) + 1;
        plot(local_ny, local_nx, 'b^', 'MarkerSize', 10, 'LineWidth', 1.5);
    end
end

hold off;
title(sprintf('Pixel q (%d, %d)', x_q, y_q), 'FontSize', 12);
xlabel('Column'); ylabel('Row');
legend('Target Pixel', '4-Neighborhood', 'Diagonal Neighborhood', 'Location', 'best');

subplot(1,3,3);
imshow(region_r, []);
hold on;

local_x_r = x_r - x_range_r(1) + 1;
local_y_r = y_r - y_range_r(1) + 1;
plot(local_y_r, local_x_r, 'ro', 'MarkerSize', 12, 'LineWidth', 2);

for i = 1:4
    nx = x_r + offsets_4(i,1);
    ny = y_r + offsets_4(i,2);
    if nx >= x_range_r(1) && nx <= x_range_r(2) && ny >= y_range_r(1) && ny <= y_range_r(2)
        local_nx = nx - x_range_r(1) + 1;
        local_ny = ny - y_range_r(1) + 1;
        plot(local_ny, local_nx, 'gs', 'MarkerSize', 10, 'LineWidth', 1.5);
    end
end

for i = 1:4
    nx = x_r + offsets_diag(i,1);
    ny = y_r + offsets_diag(i,2);
    if nx >= x_range_r(1) && nx <= x_range_r(2) && ny >= y_range_r(1) && ny <= y_range_r(2)
        local_nx = nx - x_range_r(1) + 1;
        local_ny = ny - y_range_r(1) + 1;
        plot(local_ny, local_nx, 'b^', 'MarkerSize', 10, 'LineWidth', 1.5);
    end
end

hold off;
title(sprintf('Pixel r (%d, %d)', x_r, y_r), 'FontSize', 12);
xlabel('Column'); ylabel('Row');
legend('Target Pixel', '4-Neighborhood', 'Diagonal Neighborhood', 'Location', 'best');

sgtitle('Figure 1: Neighborhood Visualization of Three Pixels', 'FontSize', 14);

end

function [region, x_range, y_range] = getLocalRegion(I, x, y, radius)

[rows, cols] = size(I);
x_start = max(1, x - radius);
x_end = min(rows, x + radius);
y_start = max(1, y - radius);
y_end = min(cols, y + radius);

region = I(x_start:x_end, y_start:y_end);
x_range = [x_start, x_end];
y_range = [y_start, y_end];

end
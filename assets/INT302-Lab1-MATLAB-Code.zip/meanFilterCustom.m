
function im_filtered = meanFilterCustom(im, window_size)
    [rows, cols] = size(im);
    pad = floor(window_size / 2);
    im_padded = padarray(im, [pad, pad], 0, 'both');
    im_filtered = zeros(rows, cols);
    
    for i = 1:rows
        for j = 1:cols
            window = im_padded(i:i+window_size-1, j:j+window_size-1);
            im_filtered(i, j) = mean(window(:));
        end
    end
end
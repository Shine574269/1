function im_noisy = addCombinedNoise(im, density, mean_val, var_val)
    [rows, cols] = size(im);
    im_noisy = im;
    num_noise = round(rows * cols * density);
    
    for k = 1:num_noise
        row = randi(rows);
        col = randi(cols);
        noise = mean_val + sqrt(var_val) * randn();
        im_noisy(row, col) = im(row, col) + noise / 255;
        im_noisy(row, col) = max(0, min(1, im_noisy(row, col)));
    end
end
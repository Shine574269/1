function [neigh4_coords, neigh4_vals, neigh8_coords, neigh8_vals] = getNeighbors(I, x, y, method)


if nargin < 4
    method = 'nan';
end

[rows, cols] = size(I);


offsets_4 = [-1, 0; 1, 0; 0, -1; 0, 1];

offsets_8 = [-1, -1; -1, 0; -1, 1; 0, -1; 0, 1; 1, -1; 1, 0; 1, 1];


[neigh4_coords, neigh4_vals] = getNeighborsHelper(I, x, y, offsets_4, rows, cols, method);


[neigh8_coords, neigh8_vals] = getNeighborsHelper(I, x, y, offsets_8, rows, cols, method);

end

function [coords, vals] = getNeighborsHelper(I, x, y, offsets, rows, cols, method)


num_neighbors = size(offsets, 1);
coords = zeros(num_neighbors, 2);
vals = zeros(num_neighbors, 1);

for i = 1:num_neighbors
    nx = x + offsets(i, 1);
    ny = y + offsets(i, 2);
    
   
    if nx >= 1 && nx <= rows && ny >= 1 && ny <= cols
        coords(i, :) = [nx, ny];
        vals(i) = I(nx, ny);
    else
        
        coords(i, :) = [nx, ny];
        if strcmp(method, 'replicate')
            vals(i) = I(x, y);  %
        else %
            vals(i) = NaN;
        end
    end
end

end